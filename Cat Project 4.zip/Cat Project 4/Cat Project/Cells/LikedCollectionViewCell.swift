//
//  LikedCollectionViewCell.swift
//  Cat Project
//
//  Created by Farangis Akhmedova on 14/04/2021.
//

import UIKit

class LikedCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var removeButton: UIButton!
    
    @IBOutlet weak var collectionView: UIImageView!
    
    let arr = UserDefaults.standard.imageArray(forKey: "images")
    
    @IBAction func removeImage(_ sender: Any) {
        
    }
}
